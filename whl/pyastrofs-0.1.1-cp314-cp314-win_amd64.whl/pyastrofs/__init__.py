from .pyastrofs import *

__doc__ = pyastrofs.__doc__
if hasattr(pyastrofs, "__all__"):
    __all__ = pyastrofs.__all__